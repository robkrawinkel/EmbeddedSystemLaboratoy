This directory contains a Quartus II project named nios2_quartus2_project for
use in the Nios II Hardware Development Tutorial.
 
The intent is for you to develop a system (in Qsys) and place it in the 
empty spot in the nios2_quartus2_project BDF (schematic).
 
For details, please read the Nios II Hardware Development Tutorial.

